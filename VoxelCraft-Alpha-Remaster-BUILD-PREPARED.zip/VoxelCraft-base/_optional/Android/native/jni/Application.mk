APP_PLATFORM := ${APP_PLATFORM}
APP_ABI := ${TARGET_ABI}
APP_STL := c++_static
APP_SHORT_COMMANDS := true
APP_MODULES := MultiCraft

ifdef NDEBUG
APP_CFLAGS := -O3 -ffast-math -fvisibility=hidden -Wno-extra-tokens -D__FILE__=__FILE_NAME__ -Wno-builtin-macro-redefined
else
APP_CFLAGS := -g -D_DEBUG -O1 -fno-omit-frame-pointer
endif

APP_CFLAGS += -flto -std=gnu17 -ffunction-sections -fdata-sections

APP_CXXFLAGS := -fvisibility-inlines-hidden -fexceptions -frtti -std=gnu++17

# Silence Irrlicht warnings. Comment out with real debugging!
APP_CXXFLAGS += -Wno-inconsistent-missing-override

ifdef NDEBUG
APP_LDFLAGS := -Wl,--gc-sections,--icf=all -Wl,-O2
endif
APP_LDFLAGS += -flto
