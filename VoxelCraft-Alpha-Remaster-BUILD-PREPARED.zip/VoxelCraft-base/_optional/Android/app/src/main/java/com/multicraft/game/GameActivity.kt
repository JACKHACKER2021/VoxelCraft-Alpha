/*
MultiCraft
Copyright (C) 2014-2026 MoNTE48, Maksim Gamarnik <Maksym48@pm.me>
Copyright (C) 2014-2026 ubulem,  Bektur Mambetov <berkut87@gmail.com>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3.0 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

package com.multicraft.game

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.drawable.AnimationDrawable
import android.os.*
import android.text.InputType
import android.view.*
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
import android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.browser.customtabs.CustomTabsIntent
import androidx.browser.customtabs.CustomTabsIntent.SHARE_STATE_OFF
import androidx.core.net.toUri
import com.multicraft.game.databinding.*
import com.multicraft.game.helpers.*
import com.multicraft.game.helpers.ApiLevelHelper.isAndroid10
import com.multicraft.game.helpers.ApiLevelHelper.isAndroid11
import com.multicraft.game.helpers.ApiLevelHelper.isAndroid12
import com.multicraft.game.helpers.ApiLevelHelper.isOreo
import com.multicraft.game.helpers.PreferenceHelper.TAG_BUILD_VER
import com.multicraft.game.helpers.PreferenceHelper.getIntValue
import com.multicraft.game.helpers.PreferenceHelper.set
import org.libsdl.app.SDLActivity
import java.io.File
import kotlin.math.roundToInt
import kotlin.system.exitProcess

class GameActivity : SDLActivity() {
	companion object {
		var isMultiPlayer = false
		var isInputActive = false

		@JvmStatic
		fun getContext(): Context {
			return SDLActivity.getContext()
		}

		@JvmStatic
		external fun pauseGame()

		@JvmStatic
		external fun keyboardEvent(keyboard: Boolean)

		@JvmStatic
		external fun update(key: String, value: String)

		@JvmStatic
		external fun setInputDialogActive(value: Boolean)
	}

	private var splashView: View? = null
	private lateinit var prefs: SharedPreferences
	private var isExtract: Boolean = false
	private var messageReturnValue = ""
	private var hasKeyboard = false
	override fun getLibraries() = arrayOf("MultiCraft")

	override fun getMainSharedObject() =
		"${getContext().applicationInfo.nativeLibraryDir}/libMultiCraft.so"

	override fun onCreate(savedInstanceState: Bundle?) {
		try {
			super.onCreate(savedInstanceState)
		} catch (_: Error) {
			exitProcess(0)
		} catch (_: Exception) {
			exitProcess(0)
		}
		prefs = PreferenceHelper.init(this)
		// Android opens this activity by itself too, as from the recent apps after an update
		val buildVer = try { prefs.getIntValue(TAG_BUILD_VER) } catch (_: ClassCastException) { 0 }
		isExtract = intent.getBooleanExtra("update", false) || buildVer != BuildConfig.VERSION_CODE
		if (isExtract) {
			val container = FrameLayout(this).apply {
				layoutParams = ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT)
				setBackgroundResource(R.drawable.bg)
			}
			val binding = ActivityMainBinding.inflate(layoutInflater)
			container.addView(binding.root)
			splashView = container
			(binding.loadingAnim.drawable as AnimationDrawable).start()
			window.addContentView(
				container,
				ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT)
			)
		}
		hasKeyboard = hasHardKeyboard()
	}

	override fun onWindowFocusChanged(hasFocus: Boolean) {
		if (!hasFocus && isInputActive)
			return

		super.onWindowFocusChanged(hasFocus)
		if (hasFocus) window.makeFullScreen()
	}

	override fun onPause() {
		super.onPause()
		pauseGame()
	}

	override fun onResume() {
		super.onResume()
		if (hasKeyboard) {
			try {
				keyboardEvent(true)
			} catch (_: UnsatisfiedLinkError) {
			}
		}
		window.makeFullScreen()
	}

	override fun onConfigurationChanged(newConfig: Configuration) {
		super.onConfigurationChanged(newConfig)
		val statusKeyboard = hasHardKeyboard()
		if (hasKeyboard != statusKeyboard) {
			hasKeyboard = statusKeyboard
			keyboardEvent(hasKeyboard)
		}
	}

	fun showDialog(hint: String?, current: String?, editType: Int) {
		isInputActive = true
		messageReturnValue = ""
		if (editType == 1)
			runOnUiThread { showMultiLineDialog(hint, current) }
		else
			runOnUiThread { showSingleDialog(hint, current, editType) }
	}

	private fun showSingleDialog(hint: String?, current: String?, editType: Int) {
		val builder = AlertDialog.Builder(this, R.style.FullScreenDialogStyle)
		val binding = InputTextBinding.inflate(layoutInflater)
		var hintText: String = hint?.ifEmpty {
			resources.getString(if (editType == 3) R.string.input_password else R.string.input_text)
		}.toString()
		hintText = hintText.replace(":$".toRegex(), "")
		binding.input.hint = hintText
		builder.setView(binding.root)
		val alertDialog = builder.create()
		val editText = binding.editText
		editText.requestFocus()
		editText.setText(current.toString())
		editText.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN
		val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
		var inputType = InputType.TYPE_CLASS_TEXT
		if (editType == 3) {
			inputType = inputType or InputType.TYPE_TEXT_VARIATION_PASSWORD
			if (isOreo())
				editText.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
		}
		editText.inputType = inputType
		editText.setSelection(editText.text?.length ?: 0)
		// for Android OS
		editText.setOnEditorActionListener { _: TextView?, keyCode: Int, _: KeyEvent? ->
			if (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_ENDCALL) {
				imm.hideSoftInputFromWindow(editText.windowToken, 0)
				messageReturnValue = editText.text.toString()
				alertDialog.dismiss()
				isInputActive = false
				setInputDialogActive(false)
				return@setOnEditorActionListener true
			}
			return@setOnEditorActionListener false
		}
		if (isChromebook()) {
			editText.setOnKeyListener { _: View?, keyCode: Int, _: KeyEvent? ->
				if (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_ENDCALL) {
					imm.hideSoftInputFromWindow(editText.windowToken, 0)
					messageReturnValue = editText.text.toString()
					alertDialog.dismiss()
					isInputActive = false
					setInputDialogActive(false)
					return@setOnKeyListener true
				}
				return@setOnKeyListener false
			}
		}
		binding.input.setEndIconOnClickListener {
			imm.hideSoftInputFromWindow(editText.windowToken, 0)
			messageReturnValue = editText.text.toString()
			alertDialog.dismiss()
			isInputActive = false
			setInputDialogActive(false)
		}
		binding.rl.setOnClickListener {
			window.setSoftInputMode(SOFT_INPUT_STATE_ALWAYS_HIDDEN)
			messageReturnValue = current.toString()
			alertDialog.dismiss()
			isInputActive = false
			setInputDialogActive(false)
		}
		val alertWindow = alertDialog.window!!
		// should be above `show()`
		alertWindow.setSoftInputMode(SOFT_INPUT_STATE_VISIBLE)
		alertDialog.show()
		if (!isTabletDp())
			alertWindow.makeFullScreenAlert()
		alertDialog.setOnCancelListener {
			window.setSoftInputMode(SOFT_INPUT_STATE_ALWAYS_HIDDEN)
			messageReturnValue = current.toString()
			isInputActive = false
			setInputDialogActive(false)
		}
	}

	private fun showMultiLineDialog(hint: String?, current: String?) {
		val builder = AlertDialog.Builder(this, R.style.FullScreenDialogStyle)
		val binding = MultilineInputBinding.inflate(layoutInflater)
		var hintText: String = hint?.ifEmpty {
			resources.getString(R.string.input_text)
		}.toString()
		hintText = hintText.replace(":$".toRegex(), "")
		binding.multiInput.hint = hintText
		builder.setView(binding.root)
		val alertDialog = builder.create()
		val editText = binding.multiEditText
		editText.requestFocus()
		editText.setText(current.toString())
		editText.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN
		editText.setSelection(editText.text?.length ?: 0)
		val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
		// for Android OS
		editText.setOnEditorActionListener { _: TextView?, keyCode: Int, _: KeyEvent? ->
			if (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_ENDCALL) {
				imm.hideSoftInputFromWindow(editText.windowToken, 0)
				messageReturnValue = editText.text.toString()
				alertDialog.dismiss()
				isInputActive = false
				setInputDialogActive(false)
				return@setOnEditorActionListener true
			}
			return@setOnEditorActionListener false
		}
		if (isChromebook()) {
			editText.setOnKeyListener { _: View?, keyCode: Int, _: KeyEvent? ->
				if (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_ENDCALL) {
					imm.hideSoftInputFromWindow(editText.windowToken, 0)
					messageReturnValue = editText.text.toString()
					alertDialog.dismiss()
					isInputActive = false
					setInputDialogActive(false)
					return@setOnKeyListener true
				}
				return@setOnKeyListener false
			}
		}
		binding.multiInput.setEndIconOnClickListener {
			imm.hideSoftInputFromWindow(editText.windowToken, 0)
			messageReturnValue = editText.text.toString()
			alertDialog.dismiss()
			isInputActive = false
			setInputDialogActive(false)
		}
		binding.multiRl.setOnClickListener {
			window.setSoftInputMode(SOFT_INPUT_STATE_ALWAYS_HIDDEN)
			messageReturnValue = current.toString()
			alertDialog.dismiss()
			isInputActive = false
			setInputDialogActive(false)
		}
		// should be above `show()`
		val alertWindow = alertDialog.window!!
		alertWindow.setSoftInputMode(SOFT_INPUT_STATE_VISIBLE)
		alertDialog.show()
		if (!isTabletDp())
			alertWindow.makeFullScreenAlert()
		alertDialog.setOnCancelListener {
			window.setSoftInputMode(SOFT_INPUT_STATE_ALWAYS_HIDDEN)
			messageReturnValue = current.toString()
			isInputActive = false
			setInputDialogActive(false)
		}
	}

	fun getDialogValue(): String {
		val value = messageReturnValue
		messageReturnValue = ""
		return value
	}

	fun getDensity() = resources.displayMetrics.density

	fun getMaxRefreshRate() =
		(if (isAndroid11()) display else @Suppress("DEPRECATION") windowManager.defaultDisplay)?.run {
			supportedModes.filter { it.physicalWidth == mode.physicalWidth && it.physicalHeight == mode.physicalHeight }
				.maxOfOrNull { it.refreshRate }?.roundToInt()
		} ?: 0

	fun notifyServerConnect(multiplayer: Boolean) {
		isMultiPlayer = multiplayer
	}

	fun notifyExitGame() {
	}

	@Suppress("unused")
	fun openURI(uri: String?, untrusted: Boolean): Boolean {
		if (uri == null) return false

		val builder = CustomTabsIntent.Builder()
			.setShareState(SHARE_STATE_OFF)
			.setShowTitle(true)
			.setUrlBarHidingEnabled(true)
			.setStartAnimations(this, R.anim.slide_in_bottom, R.anim.slide_out_top)
			.setExitAnimations(this, R.anim.slide_in_top, R.anim.slide_out_bottom)
			.build()
		builder.launchUrl(this, uri.toUri())

		return true
	}

	fun finishGame(exc: String?) {
		print(exc)
		finishApp(true)
	}

	fun handleError(exc: String?) {
		print(exc)
	}

	fun upgrade(item: String?, extra: String?): Boolean {
		if (extra != "") return true
		return item?.isEmpty() ?: false
	}

	fun getSecretKey(secret: String?): String {
		return secret ?: ""
	}

	fun hideSplashScreen() {
		if (File(filesDir, "builtin/mainmenu/init.lua").canRead())
			prefs[TAG_BUILD_VER] = BuildConfig.VERSION_CODE
		runOnUiThread {
			splashView?.let { view ->
				(view.parent as? ViewGroup)?.removeView(view)
				splashView = null
			}
		}
	}

	fun needsExtractAssets() = isExtract

	fun isGooglePC() =
		packageManager.hasSystemFeature("com.google.android.play.feature.HPE_EXPERIENCE")

	fun vibrationEffect(intensity: Int) {
		val effect: Int = if (isAndroid10()) {
			when (intensity) {
				1 -> VibrationEffect.EFFECT_TICK
				2 -> VibrationEffect.EFFECT_CLICK
				3 -> VibrationEffect.EFFECT_HEAVY_CLICK
				else -> return
			}
		} else {
			when (intensity) {
				1 -> 60
				2 -> 120
				3 -> 240
				else -> return
			}
		}
		if (isAndroid12()) {
			val vibrator = getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager
			vibrator?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(effect))
		} else if (isAndroid10()) @Suppress("DEPRECATION") {
			val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator
			vibrator?.vibrate(VibrationEffect.createPredefined(effect))
		} else if (isOreo()) @Suppress("DEPRECATION") {
			val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator
			vibrator?.vibrate(VibrationEffect.createOneShot(20L, effect))
		}
		// Vibration is not available in earlier versions,
		// as it is difficult to predict the type of vibration.
	}
}
