#! /bin/bash -eu

mkdir -p cmakebuild
cd cmakebuild
cmake -DCMAKE_BUILD_TYPE=Debug \
	-DUSE_SDL=ON \
	-DIRRLICHT_SOURCE_DIR="../deps/Irrlicht" \
	-DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
	-DRUN_IN_PLACE=TRUE \
	-DENABLE_{GETTEXT,SOUND}=FALSE \
	-DBUILD_SERVER=TRUE ..
make GenerateVersion

cd ..

./util/ci/run-clang-tidy.py \
	-clang-tidy-binary=clang-tidy-11 -p cmakebuild \
	-quiet -config="$(cat .clang-tidy)" \
	'src/.*'
